#!/bin/bash

echo -e "Username: $USER\n"
echo -e "Time and date: $(date)\n"
echo "Shell jobs for $USER:"
if [ -z "$(jobs)" ]; then
  echo "There are currently no shell jobs."
else
  jobs
fi
echo -e "\nAll processes for user: $USER:"
ps -u $USER -o user,pid,ppid,tty,command
echo -e "\nCurrent memory usage:"
free -h
echo -e "\nTotal number of processes:"
ps aux | wc -l
